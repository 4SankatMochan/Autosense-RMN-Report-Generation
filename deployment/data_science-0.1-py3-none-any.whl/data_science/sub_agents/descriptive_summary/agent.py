# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# You may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Descriptive Summary Agent that combines multiple descriptive insights.
"""

from google.adk.agents import Agent
from .tools import summarize_insights

descriptive_summary_agent = Agent(
    name="descriptive_summary_agent",
    instruction="Summarize multiple descriptive insights into a cohesive narrative.",
    tools=[summarize_insights]
)
